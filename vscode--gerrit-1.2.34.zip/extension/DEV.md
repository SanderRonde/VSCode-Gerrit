## Handy resources

-   [Gerrit API Docs](https://gerrit-review.googlesource.com/Documentation/rest-api.html)
-   [Gerrit Changes API Docs](https://gerrit-review.googlesource.com/Documentation/rest-api-changes.html)
-   [Gerrit filter docs](https://gerrit-review.googlesource.com/Documentation/user-search.html)
-   [VSCode codicons](https://microsoft.github.io/vscode-codicons/dist/codicon.html)
-   [VSCode treeview API docs](https://code.visualstudio.com/api/extension-guides/tree-view)
-   [VSCode webview API docs](https://code.visualstudio.com/api/extension-guides/webview)
-   [VSCode theme color reference](https://code.visualstudio.com/api/references/theme-color)
